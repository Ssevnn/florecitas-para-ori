# Para Orielys 💛

## Publicarlo en GitHub Pages

1. Crea un repositorio nuevo en GitHub.
2. Sube `index.html`.
3. Ve a **Settings → Pages**.
4. En **Build and deployment**, selecciona:
   - Source: **Deploy from a branch**
   - Branch: `main`
   - Folder: `/ (root)`
5. Guarda y espera unos minutos.
6. GitHub te dará el enlace público de la página.

No necesita servidor ni base de datos: todo el efecto visual y los scripts están dentro de `index.html`.
